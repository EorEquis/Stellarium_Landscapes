## Marathon Motel and RV Park

A landscape centered on pad 2 of the telescope area at Marathon Motel and RV park in Marathon, TX.

- Latitude = +30° 12' 30" N 
- Longitude = +103° 15' 16" W
- Altitude = 1235m